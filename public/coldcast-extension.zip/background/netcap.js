import { send } from './connection.js';

// ============================================================================
// Banner-free capture of salesApiLeadSearch via chrome.webRequest — NO
// chrome.debugger, so NO "being debugged" banner.
//
// webRequest can OBSERVE the exact request the page/worker makes (URL, method,
// headers, POST body) but cannot read response bodies. So we observe the search
// request the UI fires, then REPLAY that one request from the service worker
// (user's cookies, CORS-exempt via host permissions) to read the body — then
// hand it to the bridge exactly like the old debugger path did. This is the
// same replay technique Lusha/SalesQL/ContactOut already use.
//
// Scoped to the scraper's working tab, so the user's other browsing is ignored.
// ============================================================================

const patterns = new Set();
export function addPattern(m)    { if (m) patterns.add(m); }
export function removePattern(m) { if (m) patterns.delete(m); }
function wanted(url) { for (const m of patterns) if (url && url.includes(m)) return true; return false; }

let captureTabId = null;
const seen   = new Set();   // urls already replayed (dedupe)
const bodies = new Map();   // requestId → request body text (for POST/PUT)

export function setCaptureTab(id) { captureTabId = id; seen.clear(); bodies.clear(); }

// Browser-controlled headers fetch() refuses to set; cookies ride along via
// credentials:'include'.
const FORBIDDEN = new Set([
  'cookie', 'origin', 'referer', 'user-agent', 'host', 'content-length',
  'connection', 'accept-encoding', 'accept-charset', 'date', 'dnt',
  'sec-fetch-mode', 'sec-fetch-site', 'sec-fetch-dest', 'sec-fetch-user',
  'transfer-encoding', 'upgrade', 'via', 'trailer',
]);

function onBeforeRequest(d) {
  try {
    if (d.tabId !== captureTabId || !wanted(d.url) || !d.requestBody) return;
    const rb = d.requestBody;
    if (rb.raw && rb.raw.length) {
      let len = 0; const parts = [];
      for (const r of rb.raw) if (r && r.bytes) { const u = new Uint8Array(r.bytes); parts.push(u); len += u.length; }
      const all = new Uint8Array(len); let off = 0;
      for (const p of parts) { all.set(p, off); off += p.length; }
      bodies.set(d.requestId, new TextDecoder('utf-8').decode(all));
    } else if (rb.formData) {
      bodies.set(d.requestId, JSON.stringify(rb.formData));
    }
  } catch {}
}

function onSendHeaders(d) {
  try {
    if (d.tabId !== captureTabId || !wanted(d.url)) return;
    const headers = {};
    for (const h of (d.requestHeaders || [])) {
      if (h && h.name && !FORBIDDEN.has(h.name.toLowerCase())) headers[h.name] = h.value;
    }
    const body = bodies.get(d.requestId);
    bodies.delete(d.requestId);
    void replay(d.url, d.method || 'GET', headers, body);
  } catch {}
}

async function replay(url, method, headers, body) {
  if (seen.has(url)) return;          // each unique search request replayed once
  seen.add(url);
  try {
    const init = { method, headers, credentials: 'include' };
    if (body && method !== 'GET' && method !== 'HEAD') init.body = body;
    const res = await fetch(url, init);
    const text = await res.text();
    if (res.ok && text) send({ type: 'captured', url, body: text });
    else seen.delete(url);            // non-2xx → allow a later retry
  } catch (e) {
    seen.delete(url);                 // transient failure → allow retry
  }
}

let registered = false;
export function ensureWebRequest() {
  if (registered) return;
  if (!chrome.webRequest) { try { console.warn('[vl] webRequest API unavailable'); } catch {} return; }
  try {
    const filter = { urls: ['*://www.linkedin.com/*'] };
    chrome.webRequest.onBeforeRequest.addListener(onBeforeRequest, filter, ['requestBody']);
    chrome.webRequest.onSendHeaders.addListener(onSendHeaders, filter, ['requestHeaders', 'extraHeaders']);
    registered = true;
  } catch (e) { try { console.warn('[vl] webRequest register failed: ' + (e && e.message)); } catch {} }
}
