import { send } from './connection.js';
import { addPattern, removePattern, setCaptureTab } from './netcap.js';

let workingTabId = null;

const keys = new Set();
export function keep(u) {
  for (const m of keys) if (u && u.includes(m)) return true;
  return false;
}

// A salesApiLeadSearch response captured PAGE-SIDE (MAIN-world fetch / Worker
// hook). The extension no longer uses chrome.debugger at all — this is the SOLE
// capture path now — so Chrome never shows the "being debugged" banner. We
// forward each real search response to the bridge, exactly like the old
// debugger path did, so the server side is unchanged.
function looksLikeSearch(body) {
  if (typeof body !== 'string' || body.length < 200) return false;
  if (body.indexOf('"elements"') === -1 && body.indexOf('salesApiLeadSearch') === -1) return false;
  try {
    const j = JSON.parse(body);
    return !!(j && (Array.isArray(j.elements) || Array.isArray(j.data) || Array.isArray(j.results)));
  } catch { return false; }
}

export function onHookCapture(url, body) {
  if (keep(url) && looksLikeSearch(body)) send({ type: 'captured', url, body });
}

const FORBIDDEN_HEADERS = new Set([
  'cookie', 'origin', 'referer', 'user-agent', 'host',
  'content-length', 'connection', 'accept-encoding',
]);

async function ensureTab(url) {
  if (workingTabId != null) {
    try { await chrome.tabs.get(workingTabId); } catch { workingTabId = null; }
  }
  if (workingTabId == null) {
    const tab = await chrome.tabs.create({ url: 'about:blank', active: true });
    workingTabId = tab.id;
    setCaptureTab(workingTabId);   // scope capture to this tab BEFORE navigating (search fires on load)
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch {}
    if (url) { await chrome.tabs.update(workingTabId, { url }); await waitForComplete(workingTabId); }
  } else if (url) {
    setCaptureTab(workingTabId);   // scope capture to this tab BEFORE navigating
    let prevUrl = '';
    try { prevUrl = (await chrome.tabs.get(workingTabId)).url || ''; } catch {}
    await chrome.tabs.update(workingTabId, { url, active: true });
    // chrome.tabs.update only triggers a real page load when the part BEFORE the
    // '#' changes. Sales Nav search URLs are hash-routed, so pointing the SAME tab
    // at a new search (same /sales/search/… base, different #filters/page) is
    // treated as an in-page hashchange — the SPA keeps showing the PREVIOUS search
    // at its last page. That's the "Add to existing list opens the old list where
    // it stopped, not the new URL" bug. Force a real reload whenever the pre-hash
    // base is unchanged so the new URL loads fresh. A genuine cross-document change
    // (different path/query) already reloads on its own, so this is a no-op there.
    const preHash = (u) => String(u || '').split('#')[0];
    if (prevUrl && preHash(prevUrl) === preHash(url)) {
      try { await chrome.tabs.reload(workingTabId); } catch {}
    }
    try { const t = await chrome.tabs.get(workingTabId); await chrome.windows.update(t.windowId, { focused: true }); } catch {}
    await waitForComplete(workingTabId);
  }
  return workingTabId;
}

function waitForComplete(tabId, timeout = 30000) {
  return new Promise((resolve) => {
    const deadline = Date.now() + timeout;
    const tick = async () => {
      try {
        const t = await chrome.tabs.get(tabId);
        if (t.status === 'complete') return resolve(true);
      } catch { return resolve(false); }
      if (Date.now() > deadline) return resolve(false);
      setTimeout(tick, 250);
    };
    tick();
  });
}

async function sendToTab(cmd, args) {
  const tabId = await ensureTab();
  return chrome.tabs.sendMessage(tabId, { t: 'cmd', cmd, args });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// SalesQL keeps its token/uid in app.salesql.com localStorage (not cookies). The
// salesql-auth content script mirrors them into chrome.storage whenever a SalesQL tab
// is open (heartbeat `at`). When none is open (stale `at`), briefly load app.salesql.com
// in a BACKGROUND tab so the content script can capture, then close it — the user's
// session cookies are shared, so no manual navigation is needed.
let _sqLastCapture = 0;
async function captureSalesqlAuth(timeoutMs = 15000) {
  const start = Date.now();
  let tab;
  try { tab = await chrome.tabs.create({ url: 'https://app.salesql.com/', active: false }); }
  catch { return null; }
  try {
    while (Date.now() - start < timeoutMs) {
      const { salesqlAuth } = await chrome.storage.local.get('salesqlAuth');
      if (salesqlAuth && salesqlAuth.token && (salesqlAuth.at || 0) >= start) return salesqlAuth;
      await sleep(400);
    }
  } finally {
    try { if (tab) await chrome.tabs.remove(tab.id); } catch {}
  }
  return null;
}

async function getSalesqlAuthEnsured() {
  const now = Date.now();
  const { salesqlAuth } = await chrome.storage.local.get('salesqlAuth');
  // Fresh (a SalesQL tab is open, or we captured recently) → use it, no tab needed.
  if (salesqlAuth && salesqlAuth.token && (now - (salesqlAuth.at || 0) < 15 * 60 * 1000)) return salesqlAuth;
  // Stale/missing → refresh via a background tab, but at most once per 90s so a
  // logged-out user (nothing to capture) doesn't reopen a tab on every page.
  if (now - _sqLastCapture < 90 * 1000) return salesqlAuth || null;
  _sqLastCapture = now;
  const captured = await captureSalesqlAuth();
  return captured || salesqlAuth || null;
}

export async function runCommand(msg) {
  switch (msg.cmd) {
    case 'navigate':
      await ensureTab(msg.url);
      return { ok: true };

    case 'getCookies': {
      const out = [];
      for (const u of (msg.urls || [])) {
        const cs = await chrome.cookies.getAll({ url: u });
        out.push(...cs.map((c) => ({ name: c.name, value: c.value, domain: c.domain })));
      }
      return out;
    }

    case 'getSalesqlAuth':
      // Returns { token, uid } from app.salesql.com's localStorage (mirrored by
      // content/salesql-auth.js). Auto-opens a background SalesQL tab to refresh when
      // no SalesQL tab is open — no manual navigation needed. Null if truly logged out.
      return getSalesqlAuthEnsured();

    case 'httpFetch': {
      const headers = {};
      for (const [k, v] of Object.entries(msg.headers || {})) {
        if (!FORBIDDEN_HEADERS.has(k.toLowerCase())) headers[k] = v;
      }
      const res = await fetch(msg.url, {
        method: msg.method || 'GET',
        headers,
        body: msg.body,
        credentials: 'include',
      });
      const body = await res.text();
      // url + redirected let the server detect an auth redirect (e.g. a logged-out
      // dashboard bounced to /login) without guessing from the body.
      return { status: res.status, body, url: res.url, redirected: res.redirected };
    }

    case 'captureOn':  keys.add(msg.match);    addPattern(msg.match);    return { ok: true };
    case 'captureOff': keys.delete(msg.match); removePattern(msg.match); return { ok: true };

    case 'waitSelector':
    case 'scroll':
    case 'click':
    case 'clickNext':
    case 'pageFetch':
    case 'url':
    case 'getMemberId':
      return sendToTab(msg.cmd, msg);

    default:
      throw new Error('unknown cmd: ' + msg.cmd);
  }
}
