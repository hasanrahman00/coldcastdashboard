// Load the shared host config for its side effect (sets globalThis.COLDCAST_*).
// Static imports run before this module's body, so the global is ready below.
import '../config.js';

// ── Multi-hub connection ─────────────────────────────────────────────────────
// The extension connects to EVERY configured scraper hub at once (Sales Nav,
// Apollo, …) over independent WebSockets, all with the same API key + profileId.
// A hub that's down just retries on its own and never affects the others. Command
// results reply to the ORIGINATING socket; captures broadcast to all (a hub that
// didn't ask for them ignores them).

let onCmd = async () => ({ error: 'no handler' });
const conns = new Map();   // url -> { ws, pingTimer }

async function ensureProfileId() {
  let { profileId } = await chrome.storage.local.get('profileId');
  if (!profileId) {
    profileId = 'p_' + crypto.randomUUID();
    await chrome.storage.local.set({ profileId });
  }
  return profileId;
}

function defaultUrls() {
  const list = globalThis.COLDCAST_DEFAULT_WS_LIST;
  return Array.isArray(list) && list.length ? list : [globalThis.COLDCAST_DEFAULT_WS];
}

async function getConfig() {
  const { serverUrl, serverUrls, apiKey } = await chrome.storage.local.get(['serverUrl', 'serverUrls', 'apiKey']);
  let urls;
  if (Array.isArray(serverUrls) && serverUrls.length) urls = serverUrls;      // explicit multi-override
  else if (serverUrl) urls = [serverUrl];                                     // legacy single override → that one only
  else urls = defaultUrls();
  return { urls, apiKey: apiKey || '', profileId: await ensureProfileId() };
}

// https host for a ws:// hub url (e.g. wss://apollo.coldcast.io/ext → apollo.coldcast.io).
// The dashboard maps each scraper's configured URL host to this so it can show
// per-scraper "connected / not connected" for THIS browser + profile.
function hostOf(wsUrl) { try { return new URL(wsUrl).host; } catch { return String(wsUrl || ''); } }

// Per-hub status keyed by host: true only once the hub has REGISTERED us (sent
// `welcome`) — not merely a socket that's OPEN but about to be auth-rejected.
function writeServerStatus() {
  const serverStatus = {};
  for (const [url, s] of conns) {
    serverStatus[hostOf(url)] = !!(s && s.ready && s.ws && s.ws.readyState === WebSocket.OPEN);
  }
  chrome.storage.local.set({ serverStatus });
}

// connected = at least one hub has registered us (welcome received + socket open).
function refreshConnected() {
  const any = [...conns.values()].some((s) => s && s.ready && s.ws && s.ws.readyState === WebSocket.OPEN);
  chrome.storage.local.set({ connected: any });
  writeServerStatus();
}

function sendTo(ws, obj) {
  if (ws && ws.readyState === WebSocket.OPEN) { try { ws.send(JSON.stringify(obj)); } catch {} }
}

// Broadcast to every OPEN hub — used for captured responses + any global message.
// (Command RESULTS reply to their originating socket via sendTo, not this.)
export function send(obj) {
  for (const { ws } of conns.values()) sendTo(ws, obj);
}

function connectOne(url, cfg) {
  const prev = conns.get(url);
  try { if (prev && prev.ws) prev.ws.close(); } catch {}
  const state = { ws: null, pingTimer: null, ready: false };
  conns.set(url, state);

  let ws;
  try {
    ws = new WebSocket(url);   // throws synchronously on a malformed URL / bad scheme
  } catch (e) {
    console.warn('[vl] bad hub url, skipping:', url, String((e && e.message) || e));
    conns.delete(url);         // don't leave a dangling entry, and never abort the other hubs
    return;
  }
  state.ws = ws;

  ws.onopen = () => {
    sendTo(ws, { type: 'hello', apiKey: cfg.apiKey, profileId: cfg.profileId, meta: { ua: navigator.userAgent } });
    clearInterval(state.pingTimer);
    state.pingTimer = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) sendTo(ws, { type: 'pong' });
      else { clearInterval(state.pingTimer); refreshConnected(); }
    }, 20000);
  };

  ws.onmessage = async (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }

    if (msg.type === 'cmd') {
      try {
        const value = await onCmd(msg);
        sendTo(ws, { type: 'result', id: msg.id, value });   // reply to THIS hub
      } catch (e) {
        sendTo(ws, { type: 'result', id: msg.id, error: String(e?.message || e) });
      }
    } else if (msg.type === 'ping') {
      sendTo(ws, { type: 'pong' });
    } else if (msg.type === 'welcome') {
      state.ready = true;   // this hub has registered us → it's genuinely connected
      const patch = { authError: '', profileName: msg.profileName || '' };
      if (msg.profileId) patch.profileId = msg.profileId;
      await chrome.storage.local.set(patch);
      refreshConnected();   // recompute connected + per-hub serverStatus now
    } else if (msg.type === 'auth-error') {
      console.warn('[vl] key rejected by', url, ':', msg.reason || '');
      // Don't clobber the SHARED connected/authError from ONE hub — another hub
      // (e.g. the live Sales Nav one) may be perfectly healthy. Only surface the
      // error when NO other hub is still OPEN; otherwise just drop this socket.
      const otherOpen = [...conns.entries()].some(([u, s]) => u !== url && s.ws && s.ws.readyState === WebSocket.OPEN);
      try { ws.close(); } catch {}   // onclose → refreshConnected()
      if (!otherOpen) {
        const r = String(msg.reason || msg.message || '').toLowerCase();
        const authError = msg.message
          || ((r.includes('logout') || r.includes('logged'))
              ? 'You were logged out of Coldcast. Open your dashboard, sign in, then reconnect.'
              : 'Invalid or expired API key — paste a fresh key from your Coldcast dashboard.');
        await chrome.storage.local.set({ connected: false, authError });
      }
    }
  };

  ws.onclose = () => { state.ready = false; clearInterval(state.pingTimer); refreshConnected(); };
  ws.onerror = () => { try { ws.close(); } catch {} };
}

export async function connect(handlers = {}) {
  if (handlers.onCmd) onCmd = handlers.onCmd;
  const cfg = await getConfig();
  if (!cfg.apiKey) { console.log('[vl] no key'); return; }
  for (const url of cfg.urls) connectOne(url, cfg);
}

// Reconnect only the hubs whose socket has dropped (and connect any newly-added
// URL). Leaves healthy sockets untouched. Called periodically by the SW.
export async function ensureConnected() {
  const cfg = await getConfig();
  if (!cfg.apiKey) { chrome.storage.local.set({ connected: false }); return; }
  for (const url of cfg.urls) {
    const s = conns.get(url);
    if (!s || !s.ws || s.ws.readyState === WebSocket.CLOSED || s.ws.readyState === WebSocket.CLOSING) {
      connectOne(url, cfg);
    }
  }
  refreshConnected();
}
