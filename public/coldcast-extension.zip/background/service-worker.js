import { connect, ensureConnected } from './connection.js';
import { runCommand, onHookCapture } from './commands.js';
import { ensureWebRequest } from './netcap.js';

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.t === 'reconnect') {
    connect({ onCmd: runCommand });
    sendResponse?.({ ok: true });
    return;
  }
  if (msg?.t === 'sync') {
    // A UI surface (popup / sidebar / dashboard bridge) is being viewed. Reconcile the
    // LIVE socket state now: reconnect any dropped hub and rewrite `connected` from reality.
    // This is what corrects a stale `connected:true` that an evicted service worker left
    // behind — the viewer sees the true state instead of a frozen "Connected". (If the SW
    // was evicted, merely receiving this message restarts it, which already resets connected
    // + reconnects via the top-level code below; ensureConnected covers the still-alive SW.)
    ensureConnected();
    sendResponse?.({ ok: true });
    return;
  }
  if (msg?.t === 'captured') {
    onHookCapture(msg.url, msg.body);
    sendResponse?.({ ok: true });
    return;
  }
});

chrome.alarms.create('keepalive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(() => ensureConnected());

// Clear any stale "connected" flag on startup — the server's welcome message
// re-confirms it once the socket is actually live again.
ensureWebRequest();   // banner-free capture via webRequest + replay (registers on every SW start)
chrome.storage.local.set({ connected: false });
connect({ onCmd: runCommand });
