const $ = (id) => document.getElementById(id);
const DEFAULT_SERVER_URL = globalThis.COLDCAST_DEFAULT_WS;

// Dashboard URL = the server host over https, without the /ext socket path.
function dashUrl(serverUrl) {
  try {
    return (serverUrl || DEFAULT_SERVER_URL)
      .replace(/^wss?:/i, 'https:')
      .replace(/\/ext\/?$/i, '');
  } catch { return globalThis.COLDCAST_DEFAULT_HTTPS; }
}

const KEYS = ['serverUrl', 'apiKey', 'connected', 'profileName', 'profileId', 'authError', 'dashAccountMismatch'];

// Paint the live connection state from a storage snapshot. Does NOT touch the
// API-key input (that's prefilled once in load()) so a live onChanged re-render
// can never clobber what the user is typing.
function render(s) {
  s = s || {};
  $('dash').dataset.url = dashUrl(s.serverUrl || DEFAULT_SERVER_URL);

  // The dashboard reports when THIS browser is connected under a DIFFERENT account than
  // the one logged in there. A socket that's OPEN as someone else is NOT "connected" for
  // the user — so we never show green in that case; we show an actionable warning.
  const mism = !!s.dashAccountMismatch;
  const on = !!s.connected && !mism;
  const err = (!s.connected && s.authError) ? s.authError : '';
  // Key saved but the socket hasn't confirmed yet → "Connecting…" rather than a
  // misleading "Offline". The onChanged listener flips it to "Connected" the
  // moment the server's welcome lands.
  const connecting = !s.connected && !err && !!s.apiKey;

  $('pill').classList.toggle('on', on);
  $('pillText').textContent = on
    ? 'Connected'
    : mism ? 'Different account'
    : err ? 'Key rejected'
    : connecting ? 'Connecting…'
    : 'Offline';

  const e = $('err');
  const warn = mism
    ? 'This browser is connected to a different Coldcast account than your dashboard. Paste THIS account’s API key above and Save.'
    : err;
  if (warn) { e.textContent = warn; e.classList.add('show'); }
  else { e.classList.remove('show'); e.textContent = ''; }

  // Identity kept blank — no account/profile shown (avoids the "which account is this?" confusion).
  $('who').textContent = '';
}

async function load() {
  let s = {};
  try { s = await chrome.storage.local.get(KEYS); } catch {}
  // Blank the key box when THIS browser is connected as a DIFFERENT account, or the saved
  // key was rejected/expired — so the user pastes a fresh/correct key instead of re-saving
  // the wrong one already sitting there.
  const staleKey = !!s.dashAccountMismatch || !!s.authError;
  $('key').value = staleKey ? '' : (s.apiKey || '');   // prefill once, here only
  render(s);

  // Reconcile the LIVE socket state on open. The stored `connected` can be STALE — the MV3
  // service worker gets evicted while idle, so a dropped socket never wrote connected=false
  // and the pill would sit on a misleading "Connected". `sync` wakes the SW to re-check +
  // reconnect any dead hub; the onChanged listener repaints the true state. Sent whenever a
  // key is saved (even if we currently *think* we're connected — that's the stale case).
  if (s.apiKey) {
    try { chrome.runtime.sendMessage({ t: 'sync' }); } catch {}
  }
}

$('save').addEventListener('click', async () => {
  // Only the API key is user-supplied; the server URL is the built-in default.
  await chrome.storage.local.set({ apiKey: $('key').value.trim(), authError: '' });
  chrome.runtime.sendMessage({ t: 'reconnect' });
  $('pill').classList.remove('on');
  $('pillText').textContent = 'Connecting…';
  $('err').classList.remove('show');
});

$('dash').addEventListener('click', () => {
  chrome.tabs.create({ url: $('dash').dataset.url || dashUrl() });
});

// Live updates — the FIX. When the background flips `connected` (welcome / close
// / auth-error / keepalive), re-render from storage. This is exactly what the
// sidebar does, and what the popup was missing (it read state once and froze).
try {
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local') chrome.storage.local.get(KEYS, render);
  });
} catch {}

load();
