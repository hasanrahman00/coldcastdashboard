const $ = (id) => document.getElementById(id);
const DEFAULT_SERVER_URL = globalThis.COLDCAST_DEFAULT_WS;

// Dashboard URL = the server host over https, without the /ext socket path.
function dashUrl(serverUrl) {
  try {
    return (serverUrl || DEFAULT_SERVER_URL)
      .replace(/^wss?:/i, 'https:')
      .replace(/\/ext\/?$/i, '');
  } catch { return globalThis.COLDCAST_DEFAULT_HTTPS; }
}

const KEYS = ['serverUrl', 'apiKey', 'connected', 'profileName', 'profileId', 'authError'];

// Paint the live connection state from a storage snapshot. Does NOT touch the
// API-key input (that's prefilled once in load()) so a live onChanged re-render
// can never clobber what the user is typing.
function render(s) {
  s = s || {};
  $('dash').dataset.url = dashUrl(s.serverUrl || DEFAULT_SERVER_URL);

  const on = !!s.connected;
  const err = (!on && s.authError) ? s.authError : '';
  // Key saved but the socket hasn't confirmed yet → "Connecting…" rather than a
  // misleading "Offline". The onChanged listener flips it to "Connected" the
  // moment the server's welcome lands.
  const connecting = !on && !err && !!s.apiKey;

  $('pill').classList.toggle('on', on);
  $('pillText').textContent = on
    ? 'Connected'
    : err ? 'Key rejected'
    : connecting ? 'Connecting…'
    : 'Offline';

  const e = $('err');
  if (err) { e.textContent = err; e.classList.add('show'); }
  else { e.classList.remove('show'); e.textContent = ''; }

  const bits = [];
  if (s.profileName) bits.push(s.profileName);
  if (s.profileId) bits.push('#' + String(s.profileId).slice(0, 8));
  $('who').textContent = bits.join('  ·  ');
}

async function load() {
  let s = {};
  try { s = await chrome.storage.local.get(KEYS); } catch {}
  $('key').value = s.apiKey || '';     // prefill once, here only
  render(s);

  // If a key is saved but we're not connected, the service worker may be asleep
  // (MV3 evicts it when idle). Nudge it awake to (re)connect now — the onChanged
  // listener below reflects the result live, so the pill won't sit on "Offline".
  if (s.apiKey && !s.connected) {
    try { chrome.runtime.sendMessage({ t: 'reconnect' }); } catch {}
  }
}

$('save').addEventListener('click', async () => {
  // Only the API key is user-supplied; the server URL is the built-in default.
  await chrome.storage.local.set({ apiKey: $('key').value.trim(), authError: '' });
  chrome.runtime.sendMessage({ t: 'reconnect' });
  $('pill').classList.remove('on');
  $('pillText').textContent = 'Connecting…';
  $('err').classList.remove('show');
});

$('dash').addEventListener('click', () => {
  chrome.tabs.create({ url: $('dash').dataset.url || dashUrl() });
});

// Live updates — the FIX. When the background flips `connected` (welcome / close
// / auth-error / keepalive), re-render from storage. This is exactly what the
// sidebar does, and what the popup was missing (it read state once and froze).
try {
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local') chrome.storage.local.get(KEYS, render);
  });
} catch {}

load();
