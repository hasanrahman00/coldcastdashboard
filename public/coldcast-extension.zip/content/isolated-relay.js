// ============================================================================
// ISOLATED-world content script. The bridge between the page (MAIN world) and
// the service worker. MAIN world can't use chrome.* APIs, so it can't talk to
// the SW directly — this relay carries messages both ways.
//
//   SW  ──chrome.tabs.sendMessage──►  (here)  ──window.postMessage──►  MAIN
//   MAIN ──window.postMessage──►  (here)  ──chrome.runtime.sendMessage──►  SW
// ============================================================================
(() => {
  const TAG = '__vlbridge';
  const pending = new Map(); // postMessage id → SW sendResponse

  // SW → page command
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.t !== 'cmd') return;

    // pageFetch runs HERE, in the ISOLATED world — content-script fetches bypass
    // the page's CSP (and its service worker). A MAIN-world fetch is subject to
    // both, so LinkedIn blocks it ("Failed to fetch"); the isolated world is
    // exempt and still sends the user's same-origin cookies (credentials:include).
    if (msg.cmd === 'pageFetch') {
      const a = msg.args || {};
      const opts = { method: a.method || 'GET', credentials: 'include', headers: { ...(a.headers || {}) } };
      if (a.body != null) opts.body = a.body;
      // For non-GET (e.g. Apollo's mixed_people/search POST) auto-inject the page's
      // CSRF token (meta tag → cookie) if the caller didn't supply one — the isolated
      // world shares the page's DOM + document.cookie, so the same source works here.
      if (opts.method.toUpperCase() !== 'GET') {
        const hasCsrf = Object.keys(opts.headers).some((k) => k.toLowerCase() === 'x-csrf-token' && opts.headers[k]);
        if (!hasCsrf) {
          let t = '';
          const mt = document.querySelector('meta[name="csrf-token"]');
          if (mt) t = mt.getAttribute('content') || '';
          if (!t) { const mm = document.cookie.match(/X-CSRF-TOKEN=([^;]+)/); if (mm) t = decodeURIComponent(mm[1]); }
          if (t) opts.headers['X-CSRF-TOKEN'] = t;
        }
      }
      fetch(a.url, opts)
        .then(async (r) => sendResponse({ status: r.status, body: await r.text() }))
        .catch((e) => sendResponse({ error: String((e && e.message) || e) }));
      return true; // async response
    }

    const id = 'c_' + Math.random().toString(36).slice(2);
    pending.set(id, sendResponse);
    window.postMessage({ [TAG]: true, dir: 'down', id, cmd: msg.cmd, args: msg.args }, '*');
    return true; // keep the channel open for the async reply
  });

  // page → SW (command replies + unsolicited captures)
  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (ev.source !== window || !d || d[TAG] !== true || d.dir !== 'up') return;

    if (d.replyId && pending.has(d.replyId)) {
      const respond = pending.get(d.replyId);
      pending.delete(d.replyId);
      respond(d.error ? { error: d.error } : d.value);
    }
    // Unsolicited page-side capture (salesApiLeadSearch via the MAIN-world
    // fetch/Worker hook) → hand it to the SW, which forwards it to the bridge
    // and detaches the debugger once it confirms (removing the banner).
    if (d.cap && d.url && typeof d.body === 'string') {
      try { chrome.runtime.sendMessage({ t: 'captured', url: d.url, body: d.body }); } catch {}
    }
  });
})();
