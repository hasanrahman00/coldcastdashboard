// Coldcast dashboard bridge — runs ONLY on the Coldcast dashboard origin
// (see manifest matches). Tells the page the state of the extension in THIS
// browser profile, so the dashboard can show "this browser isn't connected
// yet" and highlight the matching profile row — something the account-level
// API can't know (it sees all browsers, not the one the page is open in).
//
// SECURITY: never expose the API key to the page — only booleans + identity.

const KEYS = ['connected', 'profileId', 'profileName', 'authError', 'apiKey', 'serverStatus'];

async function readState() {
  const s = await chrome.storage.local.get(KEYS);
  return {
    connected:   !!s.connected,
    hasKey:      !!(s.apiKey && String(s.apiKey).trim()),
    profileId:   s.profileId || '',
    profileName: s.profileName || '',
    authError:   s.authError || '',
    // Per-hub connection for THIS browser+profile, keyed by host
    // (e.g. { 'apollo.coldcast.io': true, 'companyscraper.coldcast.io': false }).
    // Lets the dashboard show accurate per-scraper status + gate Run.
    serverStatus: s.serverStatus && typeof s.serverStatus === 'object' ? s.serverStatus : {},
  };
}

function post(state) {
  window.postMessage({ source: 'coldcast-ext', type: 'state', state }, window.location.origin);
}

// Announce on load…
readState().then(post).catch(() => {});

// …push live updates (key saved, connected/welcome, auth errors)…
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (KEYS.some((k) => k in changes)) readState().then(post).catch(() => {});
});

// …and answer the page's "are you there?" ping (covers the page loading
// after this script, or a SPA route change re-subscribing).
window.addEventListener('message', (e) => {
  if (e.source !== window || !e.data || e.data.source !== 'coldcast-page') return;
  if (e.data.type === 'get-state') readState().then(post).catch(() => {});
});
