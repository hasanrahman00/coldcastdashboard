// Coldcast dashboard bridge — runs ONLY on the Coldcast dashboard origin
// (see manifest matches). Tells the page the state of the extension in THIS
// browser profile, so the dashboard can show "this browser isn't connected
// yet" and highlight the matching profile row — something the account-level
// API can't know (it sees all browsers, not the one the page is open in).
//
// SECURITY: never expose the API key to the page — only booleans + identity.

const KEYS = ['connected', 'profileId', 'profileName', 'authError', 'apiKey', 'serverStatus'];
let lastSync = 0;   // throttle the keepalive reconcile below

// SHA-256 hex of a string (Web Crypto — available in a content script on this https origin).
async function sha256hex(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(str)));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function readState() {
  const s = await chrome.storage.local.get(KEYS);
  const apiKey = s.apiKey && String(s.apiKey).trim();
  return {
    connected:   !!s.connected,
    hasKey:      !!apiKey,
    // HASH of the key ONLY (never the raw key) so the dashboard can reliably tell whether
    // THIS browser's extension is signed in under a DIFFERENT Coldcast account than the
    // dashboard login — by comparing key hashes. The machine profileId is reused across
    // accounts, so profileId-ownership gave false negatives; the key hash does not. Irreversible.
    keyHash:     apiKey ? await sha256hex(apiKey) : '',
    profileId:   s.profileId || '',
    profileName: s.profileName || '',
    authError:   s.authError || '',
    // Per-hub connection for THIS browser+profile, keyed by host
    // (e.g. { 'apollo.coldcast.io': true, 'companyscraper.coldcast.io': false }).
    // Lets the dashboard show accurate per-scraper status + gate Run.
    serverStatus: s.serverStatus && typeof s.serverStatus === 'object' ? s.serverStatus : {},
  };
}

function post(state) {
  window.postMessage({ source: 'coldcast-ext', type: 'state', state }, window.location.origin);
}

// Announce on load…
readState().then(post).catch(() => {});

// …push live updates (key saved, connected/welcome, auth errors)…
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (KEYS.some((k) => k in changes)) readState().then(post).catch(() => {});
});

// …answer the page's "are you there?" ping (covers the page loading after this
// script, or a SPA route change re-subscribing)…
window.addEventListener('message', (e) => {
  if (e.source !== window || !e.data || e.data.source !== 'coldcast-page') return;
  if (e.data.type === 'get-state') {
    // The dashboard polls this ~every 2.5s. Piggyback a THROTTLED reconcile so, while the
    // dashboard is open, the service worker stays awake and `connected` stays honest instead
    // of drifting stale after an eviction. The SW's ensureConnected reconnects any dead hub
    // and rewrites connected/serverStatus; the onChanged listener below re-posts it.
    const now = Date.now();
    if (now - lastSync > 7000) { lastSync = now; try { chrome.runtime.sendMessage({ t: 'sync' }); } catch {} }
    readState().then(post).catch(() => {});
    return;
  }
  // …and take the dashboard's verdict on whether THIS browser's extension is connected
  // under a DIFFERENT account than the one logged into the dashboard. The dashboard
  // computes it (our profileId isn't in its account's profile list); we stash it so the
  // popup + sidebar can warn instead of showing a misleading "Connected". No identity is
  // passed — just a boolean. (Not in KEYS, so this write doesn't loop back into post().)
  if (e.data.type === 'dash-state') {
    try { chrome.storage.local.set({ dashAccountMismatch: !!e.data.accountMismatch }); } catch {}
  }
});
