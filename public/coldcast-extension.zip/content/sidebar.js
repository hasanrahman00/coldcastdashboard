// ============================================================================
// Coldcast sidebar — a floating brand tab + slide-out panel, injected on
// LinkedIn (like ContactOut's side tab). Lives in a Shadow DOM so LinkedIn's
// CSS can't touch it and ours can't leak out. Pure brand presence + status +
// a launcher to the dashboard; the dashboard still drives the actual work.
// ============================================================================
(() => {
  if (window.__coldcastSidebar) return;          // single instance per page
  window.__coldcastSidebar = true;

  const DEFAULT_SERVER_URL = globalThis.COLDCAST_DEFAULT_WS;
  const dashUrl = (u) => {
    try { return (u || DEFAULT_SERVER_URL).replace(/^wss?:/i, 'https:').replace(/\/ext\/?$/i, ''); }
    catch { return globalThis.COLDCAST_DEFAULT_HTTPS; }
  };

  const host = document.createElement('div');
  host.id = 'coldcast-sidebar-host';
  host.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;';
  (document.documentElement || document.body).appendChild(host);
  const root = host.attachShadow({ mode: 'open' });

  const GRAD = 'linear-gradient(150deg,#1c2a52 0%,#111a36 58%,#0b1226 100%)';
  const BTN  = 'linear-gradient(135deg,#4f7cf5 0%,#3257d6 100%)';
  root.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      .tab {
        position: fixed; right: 0; top: 46%; transform: translateY(-50%);
        background: ${GRAD}; color: #fff; cursor: grab; user-select: none;
        border-radius: 12px 0 0 12px; padding: 14px 7px;
        box-shadow: -3px 0 14px rgba(2,6,23,.22);
        display: flex; flex-direction: column; align-items: center; gap: 9px;
        font: 700 12px/1 system-ui, sans-serif; letter-spacing: .5px;
        transition: padding .15s, box-shadow .15s;
      }
      .tab:hover { padding-right: 11px; box-shadow: -5px 0 20px rgba(2,6,23,.32); }
      .tab .v { writing-mode: vertical-rl; transform: rotate(180deg); text-transform: uppercase; }
      .tab svg { width: 26px; height: 26px; border-radius: 7px; }

      .panel {
        position: fixed; right: -344px; top: 0; height: 100%; width: 320px;
        background: #fff; box-shadow: -8px 0 30px rgba(2,6,23,.25);
        transition: right .26s cubic-bezier(.4,0,.2,1);
        display: flex; flex-direction: column;
        font: 13px/1.45 system-ui, sans-serif; color: #0f172a;
      }
      .panel.open { right: 0; }
      .phead { background: ${GRAD}; color: #fff; padding: 18px 16px; display: flex; align-items: center; gap: 11px; }
      .phead .logo { width: 34px; height: 34px; flex: none; }
      .phead .b { font-weight: 800; font-size: 18px; letter-spacing: -.3px; }
      .phead .t { font-size: 11px; color: #9fb0d8; }
      .x { margin-left: auto; cursor: pointer; opacity: .85; font-size: 22px; line-height: 1; background: none; border: 0; color: #fff; padding: 0 2px; }
      .x:hover { opacity: 1; }

      .pbody { padding: 16px; flex: 1; }
      .pill { display: inline-flex; align-items: center; gap: 7px; padding: 6px 12px; border-radius: 999px; font-weight: 700; font-size: 12px; background: #f1f5f9; color: #64748b; }
      .pill .dot { width: 8px; height: 8px; border-radius: 50%; background: #cbd5e1; }
      .pill.on { background: #ecfdf5; color: #047857; }
      .pill.on .dot { background: #10b981; box-shadow: 0 0 0 3px rgba(16,185,129,.18); }
      .who { color: #64748b; font-size: 12px; margin: 9px 2px 0; min-height: 15px; }
      .err { display: none; margin: 10px 0 0; padding: 9px 11px; border-radius: 9px; background: #fef2f2; border: 1px solid #fecaca; color: #b91c1c; font-size: 12px; font-weight: 600; line-height: 1.4; }
      .err.show { display: block; }
      .card { margin-top: 16px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 13px; color: #475569; font-size: 12px; }
      .card b { color: #0f172a; }
      .btn { display: block; width: 100%; margin-top: 14px; padding: 11px; border: 0; border-radius: 10px; font: inherit; font-weight: 700; cursor: pointer; text-align: center; background: ${BTN}; color: #fff; box-shadow: 0 5px 16px rgba(50,87,214,.4); }
      .btn:active { transform: translateY(1px); }
      .field { margin-top: 16px; }
      .lbl { display: block; font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: .4px; margin: 0 2px 6px; }
      .row { display: flex; gap: 8px; }
      .inp { flex: 1; min-width: 0; padding: 9px 11px; border: 1px solid #cbd5e1; border-radius: 9px; font: inherit; font-size: 13px; color: #0f172a; background: #fff; outline: none; }
      .inp:focus { border-color: #4f7cf5; box-shadow: 0 0 0 3px rgba(79,124,245,.18); }
      .save { flex: none; padding: 9px 16px; border: 0; border-radius: 9px; font: inherit; font-weight: 700; cursor: pointer; background: ${BTN}; color: #fff; box-shadow: 0 4px 12px rgba(50,87,214,.35); }
      .save:active { transform: translateY(1px); }
      .save:disabled { opacity: .6; cursor: default; }
      .hint { font-size: 11px; color: #94a3b8; margin: 7px 2px 0; min-height: 14px; }
      .pfoot { padding: 12px 16px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #94a3b8; text-align: center; letter-spacing: .3px; font-weight: 600; }
    </style>

    <div class="tab" id="tab" title="Coldcast">
      <svg viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#ccff00"/><g stroke="#0a0a0a" stroke-width="2.4" stroke-linecap="round" fill="none"><path d="M16 16 C16 10.5 19 8 23.5 8"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(60 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(120 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(180 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(240 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(300 16 16)"/></g></svg>
      <span class="v">Coldcast</span>
    </div>

    <div class="panel" id="panel">
      <div class="phead">
        <svg class="logo" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#ccff00"/><g stroke="#0a0a0a" stroke-width="2.4" stroke-linecap="round" fill="none"><path d="M16 16 C16 10.5 19 8 23.5 8"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(60 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(120 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(180 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(240 16 16)"/><path d="M16 16 C16 10.5 19 8 23.5 8" transform="rotate(300 16 16)"/></g></svg>
        <div><div class="b">Coldcast</div><div class="t">Lead exporter</div></div>
        <button class="x" id="close">&times;</button>
      </div>
      <div class="pbody">
        <span class="pill" id="pill"><span class="dot"></span><span id="pillText">Offline</span></span>
        <div class="who" id="who"></div>
        <div class="err" id="err"></div>
        <div class="field">
          <label class="lbl" for="key">API key</label>
          <div class="row">
            <input class="inp" id="key" type="password" placeholder="Paste your key" autocomplete="off" spellcheck="false" />
            <button class="save" id="save">Save</button>
          </div>
          <div class="hint" id="hint"></div>
        </div>
        <div class="card">Coldcast runs from your <b>dashboard</b> — open it to start a job, pick your search, and export enriched leads.</div>
        <button class="btn" id="dash">Open Dashboard&nbsp;&nbsp;↗</button>
      </div>
      <div class="pfoot">coldcast.io</div>
    </div>
  `;

  const $ = (id) => root.getElementById(id);
  const panel = $('panel');
  const tab = $('tab');
  $('close').addEventListener('click', () => panel.classList.remove('open'));

  // ── Draggable edge tab (vertical): tap to open, drag to reposition. ──────
  // The chosen Y is remembered across pages via chrome.storage.
  const clampTop = (t) => {
    const h = tab.offsetHeight || 60;
    return Math.max(4, Math.min(window.innerHeight - h - 4, t));
  };
  try {
    chrome.storage.local.get('ccTabTop', (s) => {
      const t = s && s.ccTabTop;
      if (typeof t === 'number') { tab.style.top = clampTop(t) + 'px'; tab.style.transform = 'none'; }
    });
  } catch {}

  let dragging = false, moved = false, startY = 0, startTop = 0;
  tab.addEventListener('mousedown', (e) => {
    dragging = true; moved = false;
    startY = e.clientY;
    startTop = tab.getBoundingClientRect().top;
    tab.style.cursor = 'grabbing';
    e.preventDefault();
  });
  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const dy = e.clientY - startY;
    if (Math.abs(dy) > 4) moved = true;
    tab.style.top = clampTop(startTop + dy) + 'px';
    tab.style.transform = 'none';
  });
  window.addEventListener('mouseup', () => {
    if (!dragging) return;
    dragging = false;
    tab.style.cursor = 'grab';
    if (moved) {
      const top = parseInt(tab.style.top, 10);
      if (!isNaN(top)) { try { chrome.storage.local.set({ ccTabTop: top }); } catch {} }
    } else {
      panel.classList.toggle('open');   // a genuine click → open / close
    }
  });

  let serverUrl = DEFAULT_SERVER_URL;
  $('dash').addEventListener('click', () => window.open(dashUrl(serverUrl), '_blank', 'noopener'));

  // ── API key: prefill from storage (unless stale), then save + reconnect. ──
  // "stale" = connected as a different account, or the saved key was rejected/expired →
  // leave the box BLANK so the user pastes the correct key instead of re-saving a dead one.
  let _userTyped = false;
  try {
    chrome.storage.local.get(['apiKey', 'authError', 'dashAccountMismatch'], (s) => {
      s = s || {};
      const stale = !!(s.dashAccountMismatch || s.authError);
      if (!stale && typeof s.apiKey === 'string') $('key').value = s.apiKey;
    });
  } catch {}
  $('key').addEventListener('input', () => { _userTyped = true; });
  $('save').addEventListener('click', async () => {
    const key = $('key').value.trim();
    const btn = $('save');
    try {
      btn.disabled = true;
      await chrome.storage.local.set({ apiKey: key, authError: '' });
      chrome.runtime.sendMessage({ t: 'reconnect' });   // tell the SW to (re)connect with the new key
      $('pill').classList.remove('on');
      $('pillText').textContent = 'Connecting…';
      $('err').classList.remove('show');
      $('hint').textContent = key ? 'Saved — connecting…' : 'Key cleared.';
    } catch {
      $('hint').textContent = 'Could not save — try again.';
    } finally {
      // re-read the real connection state shortly after (the onChanged listener
      // also updates it live once the socket confirms).
      setTimeout(() => { btn.disabled = false; $('hint').textContent = ''; try { chrome.storage.local.get(KEYS, render); } catch {} }, 1400);
    }
  });
  $('key').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('save').click(); });

  function render(s) {
    s = s || {};
    serverUrl = s.serverUrl || DEFAULT_SERVER_URL;   // only used to derive the dashboard link
    // Connected under a DIFFERENT account than the dashboard (reported by the dashboard
    // via the bridge) is NOT "connected" for the user — show an actionable warning, not green.
    const mism = !!s.dashAccountMismatch;
    const on = !!s.connected && !mism;
    const err = (!s.connected && s.authError) ? s.authError : '';
    // Key saved but the socket hasn't confirmed yet → "Connecting…", NOT "Offline".
    // The SW clears `connected` on every wake, which otherwise flashes "Offline" the
    // instant you hit Save and makes it look like nothing happened. Mirrors the popup.
    const connecting = !s.connected && !err && !!s.apiKey;
    $('pill').classList.toggle('on', on);
    $('pillText').textContent = on ? 'Connected' : mism ? 'Different account' : err ? 'Key rejected' : connecting ? 'Connecting…' : 'Offline';
    const e = $('err');
    const warn = mism
      ? 'This browser is connected to a different Coldcast account than your dashboard. Paste THIS account’s API key and Save.'
      : err;
    if (warn) { e.textContent = warn; e.classList.add('show'); }
    else { e.classList.remove('show'); e.textContent = ''; }
    // Identity kept blank — no account/profile shown.
    $('who').textContent = '';
    // Different account / rejected key → clear the stale key so the user pastes a fresh
    // one — but never clobber what they're actively typing.
    if ((mism || err) && !_userTyped) $('key').value = '';
  }

  // apiKey is included so render() can show "Connecting…" (never touches the input).
  const KEYS = ['serverUrl', 'apiKey', 'connected', 'profileName', 'profileId', 'authError', 'dashAccountMismatch'];
  try {
    chrome.storage.local.get(KEYS, render);
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'local') chrome.storage.local.get(KEYS, render);
    });
  } catch { render({}); }
})();
