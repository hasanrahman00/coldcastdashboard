(() => {
  // ── Coldcast page-side capture (replaces chrome.debugger) ─────────────────
  // Captures the salesApiLeadSearch response WITHOUT chrome.debugger, so the
  // "being debugged" banner can be dropped. Three vectors, every one fully
  // defensive (try/caught, native fallback) so the page can NEVER break:
  //   (a) main-thread fetch, (b) main-thread XHR — if the search runs on the
  //       page thread.
  //   (c) a Worker fetch-hook — the search is normally fetched inside a Worker,
  //       so we build the worker from a blob containing [our fetch proxy + the
  //       worker's OWN inlined source]. Because the original source is inlined
  //       (not importScripts'd), there is no second load that CSP can block and
  //       leave half-initialized. Relative importScripts/fetch inside it are
  //       rewritten back to the original base URL. On ANY problem we return the
  //       real native Worker untouched.
  // Captures ride the existing relay up to the SW, which forwards them to the
  // bridge and detaches the debugger the first time it sees a real response.
  (function () {
    try {
      // Install the capture hooks ONLY on LinkedIn — salesApiLeadSearch exists nowhere
      // else. Wrapping window.fetch / XHR on every site (Lusha, etc.) was pure overhead
      // and put this script into unrelated pages' fetch stack traces (a Lusha CSP report
      // for a blocked doubleclick tracker was blamed on main-world.js). Bail everywhere else.
      if (!/(^|\.)linkedin\.com$/i.test(location.hostname)) return;
      var HIT = 'salesApiLeadSearch';
      var CH = '__cc_cap';
      // On-page diagnostic overlay (LinkedIn only) so a single screenshot shows
      // exactly what the capture did — no console needed. Removed once it works.
      var DIAG = false;   // capture moved to chrome.webRequest (background) — overlay off
      var log = function (m) {
        try { console.log('%c[Coldcast]', 'color:#2b6cff;font-weight:bold', m); } catch (e) {}
        if (!DIAG) return;
        try {
          var el = document.getElementById('__coldcast_diag');
          if (!el) {
            el = document.createElement('div');
            el.id = '__coldcast_diag';
            el.style.cssText = 'position:fixed;z-index:2147483647;bottom:10px;left:10px;max-width:48vw;max-height:44vh;overflow:auto;background:rgba(8,16,34,.94);color:#bfe3ff;font:11px/1.45 ui-monospace,Consolas,monospace;padding:8px 11px;border:1px solid #2b6cff;border-radius:8px;white-space:pre-wrap;pointer-events:none;box-shadow:0 6px 18px rgba(0,0,0,.45)';
            el.textContent = 'Coldcast capture diagnostics — screenshot this box';
            (document.body || document.documentElement).appendChild(el);
          }
          el.textContent += '\n' + m;
        } catch (e) {}
      };
      var relayUp = function (url, body) {
        log('CAPTURED ' + ((body && body.length) || 0) + ' bytes — ' + String(url).slice(0, 70));
        try { window.postMessage({ __vlbridge: true, dir: 'up', cap: true, url: url, body: body }, '*'); } catch (e) {}
      };

      // captures posted by the in-worker fetch hook surface here
      try {
        var bc = new BroadcastChannel(CH);
        bc.onmessage = function (ev) {
          var d = ev && ev.data;
          if (d && d.url && typeof d.body === 'string') relayUp(d.url, d.body);
        };
      } catch (e) {}

      // (a) main-thread fetch — REMOVED (was the source of the "Uncaught (in promise)
      // Failed to fetch" console noise). It's redundant: chrome.webRequest (background,
      // netcap.js) already OBSERVES + REPLAYS every salesApiLeadSearch request the page
      // makes — fetch, XHR, or worker — and the XHR hook below covers same-URL in-place
      // pagination. The search is an XHR, not a fetch, so this wrapper never captured a
      // HIT; it only wrapped LinkedIn's OWN fetches, and when one of those fails
      // ("Failed to fetch" — aborted leadSearch on fast pagination, blocked telemetry)
      // Chrome roots the unhandled-rejection async stack at the fetch call site (this
      // wrapper), pinning a harmless error on us. A side .catch() couldn't relocate that
      // — the only fix is to NOT wrap window.fetch. Capture is unaffected.

      // (b) main-thread XHR
      try {
        var _open = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (method, url) {
          try {
            if (url && String(url).indexOf(HIT) !== -1) {
              this.addEventListener('load', function () {
                try {
                  var self = this, rt = self.responseType;
                  // Sales Nav's in-place PAGINATION leadSearch is a blob/arraybuffer XHR.
                  // Reading .responseText on those throws InvalidStateError (swallowed by
                  // the try/catch), so the old hook silently dropped EVERY clicked page —
                  // capture then only worked on a full navigate (webRequest). Read the body
                  // by type, like the reference extension does.
                  if (rt === 'blob' || rt === 'arraybuffer') {
                    var resp = self.response;
                    if (!resp) return;
                    var blob = (rt === 'blob') ? resp : new Blob([resp]);
                    blob.text().then(function (b) { if (b) relayUp(String(url), b); }).catch(function () {});
                  } else if (rt === 'json' && self.response != null) {
                    relayUp(String(url), JSON.stringify(self.response));
                  } else {
                    var txt = ''; try { txt = self.responseText || ''; } catch (e) {}
                    if (txt) relayUp(String(url), txt);
                  }
                } catch (e) {}
              });
            }
          } catch (e) {}
          return _open.apply(this, arguments);
        };
      } catch (e) {}

      // (c) Worker fetch-hook. This function is stringified and runs INSIDE the
      //     worker, before the worker's own (inlined) source.
      function workerHook(BASE, HIT, CH) {
        try {
          try {
            var _is = self.importScripts;
            if (typeof _is === 'function') {
              self.importScripts = function () {
                var a = Array.prototype.map.call(arguments, function (u) { try { return new URL(u, BASE).href; } catch (e) { return u; } });
                return _is.apply(self, a);
              };
            }
          } catch (e) {}
          var _f = self.fetch;
          if (typeof _f !== 'function') return;
          var bc; try { bc = new BroadcastChannel(CH); } catch (e) {}
          self.fetch = function (input, init) {
            var ai = input, u = (typeof input === 'string') ? input : (input && input.url) || '';
            try { if (typeof input === 'string') { ai = new URL(input, BASE).href; u = ai; } } catch (e) {}
            var p = _f.call(this, ai, init);
            try {
              if (bc && u && u.indexOf(HIT) !== -1) {
                p.then(function (r) { try { r.clone().text().then(function (b) { try { bc.postMessage({ url: u, body: b }); } catch (e) {} }); } catch (e) {} });
              }
            } catch (e) {}
            return p;
          };
        } catch (e) {}
      }

      // Worker injection removed — capture now happens via chrome.webRequest in
      // the background service worker (it observes the request and replays it).
      // Nothing here modifies LinkedIn's Worker, so the page can never break.

      log('page-side capture installed');
    } catch (e) { try { console.warn('[Coldcast] capture init failed:', e && e.message); } catch (e2) {} }
  })();
  // ──────────────────────────────────────────────────────────────────────────

  const TAG = '__vlbridge';

  const postUp = (extra) => window.postMessage({ [TAG]: true, dir: 'up', ...extra }, '*');


  window.addEventListener('message', async (ev) => {
    const d = ev.data;
    if (ev.source !== window || !d || d[TAG] !== true || d.dir !== 'down') return;
    let value = null, error = null;
    try { value = await exec(d.cmd, d.args || {}); }
    catch (e) { error = String(e?.message || e); }
    postUp({ replyId: d.id, value, error });
  });

  async function exec(cmd, args) {
    switch (cmd) {
      case 'url':        return location.href;
      case 'getMemberId': {
        // Read the logged-in viewer's LinkedIn member id from the page DOM.
        // Dedicated verb (NOT eval) so LinkedIn's CSP doesn't block it.
        const els = document.querySelectorAll('code, script');
        for (const el of els) {
          const t = el.textContent || '';
          if (t.length < 20 || t.length > 300000) continue;
          const mm = t.match(/"salesMemberId"\s*:\s*"?(\d+)"?/)
                  || t.match(/"currentMemberId"\s*:\s*"?(\d+)"?/)
                  || t.match(/"memberIdentity"\s*:\s*"urn:li:member:(\d+)"/);
          if (mm) return mm[1];
        }
        return '';
      }
      case 'waitSelector': return waitSelector(args.selector, args.timeout || 15000);
      case 'click': {
        const el = document.querySelector(args.selector);
        if (!el) throw new Error('no element: ' + args.selector);
        el.click();
        return { ok: true };
      }
      case 'scroll':     return humanScroll(args.mult || 1.4);
      case 'clickNext':  return clickNext();
      case 'pageFetch': {
        // NOTE: pageFetch is handled in isolated-relay.js (content-script world
        // bypasses page CSP), so this MAIN-world branch is a fallback only.
        const r = await fetch(args.url, { credentials: 'include', headers: args.headers || {} });
        return { status: r.status, body: await r.text() };
      }
      default:
        throw new Error('unknown page cmd: ' + cmd);
    }
  }

  function waitSelector(sel, timeout) {
    return new Promise((resolve) => {
      const deadline = Date.now() + timeout;
      const t = setInterval(() => {
        if (document.querySelector(sel)) { clearInterval(t); resolve({ found: true }); }
        else if (Date.now() > deadline) { clearInterval(t); resolve({ found: false }); }
      }, 250);
    });
  }

  // Burst-scroll the largest scrollable container (the lead list), mirroring the
  // original scrollDashboardPage: 10-16 steps, 2-4 scrolls/burst, smooth, with
  // speed-scaled jitter.
  async function humanScroll(mult) {
    const m = mult || 1.4;
    const rand = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
    const waitMs = (min, max) => Math.floor(rand(min, max) * m);
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const cands = Array.from(document.querySelectorAll('main, section, div, ul, ol'))
      .filter((n) => n.scrollHeight > n.clientHeight && n.offsetHeight > 300)
      .sort((a, b) => b.clientHeight - a.clientHeight);
    const el = cands[0] || document.scrollingElement || document.documentElement;
    let lastTop = -1, stall = 0;
    const totalSteps = rand(10, 16);
    let step = 0;
    while (step < totalSteps) {
      const burst = rand(2, 4);
      for (let b = 0; b < burst && step < totalSteps; b++, step++) {
        try { el.scrollBy({ top: rand(200, 420), behavior: 'smooth' }); } catch { el.scrollTop += rand(200, 420); }
        await sleep(waitMs(150, 350));
      }
      if (step < totalSteps) await sleep(waitMs(300, 700));
      const curr = el.scrollTop;
      if (curr === lastTop) { stall++; if (stall >= 3) break; } else { stall = 0; lastTop = curr; }
    }
    return { ok: true };
  }

  // Click the Sales Nav "Next" pagination button (SPA — no page reload), with up
  // to 3 attempts and ZERO scrolling. The pager button is in the DOM, so we locate
  // it with querySelector and click it IN PLACE — a programmatic click fires the
  // SPA's handler even when the button is below the fold, so the page never
  // scrolls. After each click we confirm the page ACTUALLY advanced (active
  // pagination number / first lead changes); if not, we retry. A briefly-disabled
  // button is waited out, not mistaken for the last page.
  async function clickNext() {
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const MAX_ATTEMPTS = 3;

    const find = () => {
      const sels = [
        "button[aria-label='Next'].artdeco-pagination__button--next",
        "button.artdeco-pagination__button--next",
        ".artdeco-pagination__button--next",
        "button[aria-label='Next']",
        "button[aria-label='Next page']",
      ];
      for (const s of sels) { const el = document.querySelector(s); if (el) return el; }
      // Fallback: any button/anchor whose aria-label or text is exactly "Next".
      return Array.from(document.querySelectorAll('button, a')).find((el) => {
        const a = (el.getAttribute('aria-label') || '').trim().toLowerCase();
        const t = (el.textContent || '').trim().toLowerCase();
        return a === 'next' || a === 'next page' || t === 'next';
      }) || null;
    };

    const isDisabled = (el) =>
      !!(el && (el.disabled || String(el.getAttribute('aria-disabled')).toLowerCase() === 'true'));

    // Fingerprint of the current page: the URL + active pagination number + first
    // lead href. Sales Nav updates the URL on page change, and `location.href`
    // updates even when the tab is in the BACKGROUND (no render needed), so the
    // advance is detected reliably even while the user works in another window —
    // where the DOM (number/lead) re-render is paused/throttled by Chrome.
    const pageSig = () => {
      const active = document.querySelector('[aria-current="true"]')
        || document.querySelector('.artdeco-pagination__indicator--number.active')
        || document.querySelector('li.artdeco-pagination__indicator--number.active');
      const num = active ? (active.textContent || '').trim() : '';
      const lead = document.querySelector("a[data-control-name^='view_lead_panel']");
      const href = lead ? (lead.getAttribute('href') || '') : '';
      return location.href + '##' + num + '||' + href;
    };

    // Find the Next button (querySelector finds it regardless of scroll position)
    // and wait for it to be ENABLED — NO scrolling. A transiently-disabled button
    // must not be read as the last page; only one still disabled after the wait is.
    const findClickable = async () => {
      let btn = find();
      for (let i = 0; i < 8 && !btn; i++) { await sleep(300); btn = find(); }   // poll, never scroll
      if (!btn) return { btn: null, reason: 'no-next-button' };
      for (let i = 0; i < 6 && isDisabled(btn); i++) { await sleep(300); btn = find() || btn; }
      if (isDisabled(btn)) return { btn, reason: 'disabled' };   // genuinely the last page
      return { btn, reason: null };
    };

    let lastReason = 'no-advance';
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      const before = pageSig();
      const { btn, reason } = await findClickable();
      if (reason === 'disabled') return { clicked: false, reason: 'disabled' };
      if (!btn) {
        lastReason = 'no-next-button';
        if (attempt < MAX_ATTEMPTS) { await sleep(500); continue; }   // not there yet → retry
        break;
      }

      // Click the Next button IN PLACE — no scrolling, no focus (focus would scroll it
      // into view). Matches the reference extension, which clicks the pager without ever
      // scrolling to it: a programmatic .click() fires LinkedIn's pagination handler
      // regardless of the button's position, and the resulting SPA leadSearch is captured
      // directly (blob-XHR hook). No scroll-lock either. Keeps the page perfectly still —
      // no bot-like scroll jump before each page.
      try { btn.click(); }
      catch { try { btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window })); } catch {} }

      // Confirm the page actually advanced (URL or fingerprint changed). Poll on
      // real elapsed time so a backgrounded/throttled tab still resolves: the URL
      // flips even when rendering is paused, so we catch the advance regardless.
      const deadline = Date.now() + 8000;
      while (Date.now() < deadline) {
        await sleep(250);
        if (pageSig() !== before) return { clicked: true, attempt };
      }
      lastReason = 'no-advance';   // clicked but page didn't change → retry
    }
    return { clicked: false, reason: lastReason };
  }
})();
