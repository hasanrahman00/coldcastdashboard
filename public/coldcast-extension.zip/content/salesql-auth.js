// ============================================================================
// SalesQL web-app auth mirror.
//
// SalesQL keeps its API token in localStorage['token'] and the user id in
// localStorage['ajs_user_id'] on app.salesql.com — NOT in cookies, and NOT in a
// place the scraper's getCookies can see. (The SalesQL *browser extension* keeps
// them in its own chrome.storage, which THIS extension cannot read — Chrome
// sandboxes extensions from each other.) A content script CAN read the website's
// own localStorage, so we copy the token + uid into this extension's storage,
// where the Coldcast bridge exposes them to the scraper via `getSalesqlAuth`.
//
// Runs only on *.salesql.com (see manifest). Read on load, on tab focus, and
// every 15s so a fresh login / token refresh is picked up automatically.
// ============================================================================
(() => {
  // localStorage values may be JSON-encoded (Segment stores ajs_user_id as a
  // quoted string). Unwrap a JSON string; otherwise use the raw value.
  const clean = (v) => {
    if (v == null) return '';
    try { const p = JSON.parse(v); return typeof p === 'string' ? p : String(p); }
    catch { return String(v); }
  };

  const read = () => {
    try {
      const token = clean(localStorage.getItem('token'));
      const uid   = clean(localStorage.getItem('ajs_user_id'));
      if (!token) return;                       // not logged in (yet) — leave prior value
      // Always write with a fresh `at` (a heartbeat): a recent `at` tells the bridge a
      // SalesQL tab is open + logged in, so it never needs to open its own tab. When
      // `at` goes stale, the bridge briefly opens app.salesql.com in the background to
      // refresh. Writing every 15s is negligible overhead.
      chrome.storage.local.set({ salesqlAuth: { token, uid, at: Date.now() } });
    } catch {}
  };

  read();
  setInterval(read, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) read(); });
})();
