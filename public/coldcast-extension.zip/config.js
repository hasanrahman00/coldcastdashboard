// ═══════════════════════════════════════════════════════════════════════════
// ⚙️  Coldcast extension — SINGLE SOURCE OF TRUTH for the default server host.
//
// To point the WHOLE extension (service worker + popup + content scripts) at a
// new domain, change the ONE line marked below. Every context loads this file
// and reads globalThis.COLDCAST_DEFAULT_WS:
//   • service worker (module):  import '../config.js'   — runs for side effect
//   • popup page:               <script src="../config.js"> before popup.js
//   • content scripts:          listed before sidebar.js in manifest
//
// It deliberately uses NO import/export, so the SAME file is valid as both a
// classic script (popup + content scripts) AND a side-effect ES module (the
// module service worker). Don't add import/export here or the classic contexts
// will throw.
//
// Users can still override the host at runtime via the chrome.storage
// `serverUrl` setting — this constant is only the built-in fallback.
// ═══════════════════════════════════════════════════════════════════════════

// 👉 CHANGE THIS LINE to move every part of the extension to a new server:
globalThis.COLDCAST_DEFAULT_WS = 'wss://salesnav.coldcast.io/ext';

// Every scraper hub the ONE extension connects to SIMULTANEOUSLY (same API key +
// profile). Add a scraper's /ext here and the same extension drives it too. A hub
// that's down/unreachable just retries in the background and never affects the
// others. Overridable at runtime via chrome.storage `serverUrls` (array) — or the
// legacy single `serverUrl` (which, if set, wins and connects to that one only).
globalThis.COLDCAST_DEFAULT_WS_LIST = [
  'wss://salesnav.coldcast.io/ext',
  'wss://apollo.coldcast.io/ext',
  'wss://companyscraper.coldcast.io/ext',
  'wss://linkedinenricher.coldcast.io/ext',
];

// Derived HTTPS origin (wss→https, drop the /ext path) — used for the
// "Open Dashboard" link and the malformed-URL fallback. Follows the line above
// automatically; no need to edit.
globalThis.COLDCAST_DEFAULT_HTTPS = globalThis.COLDCAST_DEFAULT_WS
  .replace(/^wss?:/i, 'https:')
  .replace(/\/ext\/?$/i, '');
